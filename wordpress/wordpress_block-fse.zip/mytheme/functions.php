<?php

    if ( ! function_exists( 'meintheme_styles' ) ) :
        function meintheme_styles() 
        {
            // Register theme stylesheet.
            $theme_version = wp_get_theme()->get( 'Version' );
            $version_string = is_string( $theme_version ) ? $theme_version : false;
            wp_register_style('meintheme-style', get_template_directory_uri() . '/style.css', array(), $version_string);  
                
            // Enqueue theme stylesheet.
            wp_enqueue_style( 'meintheme-style' );
        }

        add_action( 'wp_enqueue_scripts', 'meintheme_styles' );
    endif;

    if ( ! function_exists( 'meintheme_support' ) ) :
        function meintheme_support()  
        {
            // Adding support for core block visual styles.
            add_theme_support( 'wp-block-styles' );

            // Enqueue editor styles.
            add_editor_style( 'style.css' );
        }

        add_action( 'after_setup_theme', 'meintheme_support' );
    endif;