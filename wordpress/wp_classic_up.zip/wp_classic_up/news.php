<div id="news">
	<div class="row">
		<div class="column">
            <?php $the_query = new WP_Query('posts_per_page=6'); ?>
            <?php if ($the_query->have_posts()) : ?>
                <h2>News</h2>
                <div class="blog">
                    <!-- Loop through every Post -->
                    <?php while ($the_query->have_posts()) : $the_query->the_post(); ?>
                        <div class="post">
                            <?php if (ICL_LANGUAGE_CODE == 'de') : ?>
                                <span class="post-title"><?php the_title(); ?></span>
                                <span class="post-link"><a title="weiterlesen" href="<?php the_permalink(); ?>">weiterlesen</a></span>
                            <?php endif; ?>
                            <?php if (ICL_LANGUAGE_CODE == 'en') : ?>
                                <span class="post-title"><?php the_title(); ?></span>
                                <span class="post-link"><a title="read more" href="<?php the_permalink(); ?>">read more</a></span>                               
                            <?php endif; ?>
                        </div>
                    <?php endwhile;	wp_reset_postdata(); ?>
                </div>
            <?php endif; ?>						
		</div>
	</div>
</div>    							           
