<footer>
    <div class="row">
        <?php if (ICL_LANGUAGE_CODE == 'de') : ?>
            <div class="column">
                <h3>internes:</h3>
                <?php wp_nav_menu(array('theme_location' => 'my-intern-menu', 'container_class' => 'my-intern-menu')); ?>
            </div>
            <div class="column">
                <h3>Teilnehmende Institutionen:</h3>
                <?php wp_nav_menu(array('theme_location' => 'my-extern-menu', 'container_class' => 'my-extern-menu')); ?>
            </div>
            <div class="column">
                <h3>Vorstand:</h3>
                <?php wp_nav_menu(array('theme_location' => 'my-websites-menu', 'container_class' => 'my-websites-menu')); ?>
            </div>
            <div class="column">
                <h3>koordiniert durch:</h3>
                <a target="_blank" title="zur Homepage der Universität Potsdam" href="https://www.uni-potsdam.de/"><img src="<?php echo get_bloginfo('template_directory'); ?>/img/potsdam.png" alt="Logo der UP" loading="lazy" class="up"></a>
            </div>
            <div class="column">
                <h3>gefördert durch:</h3>
                <a target="_blank" title="zur Homepage der Deutsche Forschungsgemeinschaft e.V." href="https://www.dfg.de/"><img src="<?php echo get_bloginfo('template_directory'); ?>/img/dfg.png" alt="Logo der DFG" loading="lazy"></a>
            </div>
            <div class="column">
                <h3>in Zusammenarbeit mit:</h3>
                <a target="_blank" title="zur Homepage Ruhr-Universität Bochum" href="https://www.ruhr-uni-bochum.de/"><img src="<?php echo get_bloginfo('template_directory'); ?>/img/bochum.png" alt="Logo der RUB" loading="lazy"></a>
            </div>
        <?php endif; ?>

        <?php if (ICL_LANGUAGE_CODE == 'en') : ?>
            <div class="column">
                <h3>internal:</h3>
                <?php wp_nav_menu(array('theme_location' => 'my-intern-menu', 'container_class' => 'my-intern-menu')); ?>
            </div>
            <div class="column">
                <h3>participating institutions:</h3>
                <?php wp_nav_menu(array('theme_location' => 'my-extern-menu', 'container_class' => 'my-extern-menu')); ?>
            </div>
            <div class="column">
                <h3>executive board:</h3>
                <?php wp_nav_menu(array('theme_location' => 'my-websites-menu', 'container_class' => 'my-websites-menu')); ?>
            </div>
            <div class="column">
                <h3>coordinated by:</h3>
                <a target="_blank" title="zur Homepage der Universität Potsdam" href="https://www.uni-potsdam.de/"><img src="<?php echo get_bloginfo('template_directory'); ?>/img/potsdam.png" alt="Logo der UP" loading="lazy" class="up"></a>
            </div>
            <div class="column">
                <h3>funded by:</h3>
                <a target="_blank" title="zur Homepage der Deutsche Forschungsgemeinschaft e.V." href="https://www.dfg.de/"><img src="<?php echo get_bloginfo('template_directory'); ?>/img/dfg.png" alt="Logo der DFG" loading="lazy"></a>
            </div>
            <div class="column">
                <h3>in cooperation with:</h3>
                <a target="_blank" title="zur Homepage Ruhr-Universität Bochum" href="https://www.ruhr-uni-bochum.de/"><img src="<?php echo get_bloginfo('template_directory'); ?>/img/bochum.png" alt="Logo der RUB" loading="lazy"></a>
            </div>
        <?php endif; ?>
    </div>
</footer>