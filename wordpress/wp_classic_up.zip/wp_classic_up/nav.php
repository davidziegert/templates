<nav>
    <div class="row">
        <div class="column">
            <?php if (ICL_LANGUAGE_CODE == 'de') : ?>
                <button title="öffne Menü" id="hamburger" onclick="toggleMobileMenu()">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                <span>Menü</span>
            <?php endif; ?>  

            <?php if (ICL_LANGUAGE_CODE == 'en') : ?>
                <button title="open menu" id="hamburger" onclick="toggleMobileMenu()">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                <span>Menu</span>
            <?php endif; ?>
        </div>
        <div class="column" id="menu">
            <?php wp_nav_menu(array('theme_location' => 'my-main-menu', 'container_class' => 'my-main-menu')); ?> 
        </div>
    </div>
</nav>