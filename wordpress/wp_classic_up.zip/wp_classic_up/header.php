<header>
    <div class="line"></div>
    <div class="row">
        <div class="column">
            <?php wp_nav_menu(array('theme_location' => 'my-lang-menu', 'container_class' => 'my-lang-menu')); ?>
            <?php get_search_form(); ?>
        </div>
        <div class="column">
            <a class="logo" href="<?php echo home_url(); ?>"><img src="<?php echo get_bloginfo('template_directory'); ?>/img/logo_small.png" loading="lazy"></a>
            <a class="title" href="<?php echo home_url(); ?>"><i class="fa fa-home" aria-hidden="true"></i> <strong><?php bloginfo('name'); ?> - </strong><?php bloginfo('description'); ?></a> 
        </div> 
    </div>
</header>
