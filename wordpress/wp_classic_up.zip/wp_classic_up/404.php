<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <!-- Meta Tags -->
    <meta charset="<?php bloginfo('charset'); ?>" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="robots" content="index, follow">

    <!-- Site specific elements -->
    <title>404 | <?php bloginfo('name'); ?></title>

    <meta name="description" content="<?php add_custom_meta_description(); ?>">
    <meta name="keywords" content="Universität Potsdam, Linguistik, Sonderforschungsbereich, Variabilität, Sprache, Projekte, Modelle, Daten, University of Potsdam, Linguistics, Collaborative Research Center, Variability, Language, Projects, Models, Data">

    <!-- Open Graph Meta Tags -->
    <meta property="og:title" content="<?php the_title(); ?>">
    <meta property="og:description" content="<?php add_custom_meta_description(); ?>">
    <meta property="og:image" content="<?php echo get_bloginfo('template_directory'); ?>/img/og_image.jpg">
    <meta property="og:site_name" content="<?php bloginfo('name'); ?>">
    <meta property="og:url" content="https://www.sfb1287.uni-potsdam.de/">

    <!-- Styles -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo get_bloginfo('template_directory'); ?>/img/favicon.ico">
    <link rel="apple-touch-icon" href="<?php echo get_bloginfo('template_directory'); ?>/img/touch.png">
    <link rel="stylesheet" href="<?php echo get_bloginfo('template_directory'); ?>/style.css">
    <link rel="stylesheet" href="<?php echo get_bloginfo('template_directory'); ?>/css/reset.css">
    <link rel="stylesheet" href="<?php echo get_bloginfo('template_directory'); ?>/css/style.css">

    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Academicons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/jpswalsh/academicons@1/css/academicons.min.css">

    <!-- Wordpress specific elements -->
    <?php wp_head(); ?>
</head>

<body>
    <div class="error_404">
        <div class="error_message">
            <?php if (ICL_LANGUAGE_CODE == 'de') : ?>
                <h1>Seite wurde nicht gefunden!</h1>
                <p>Die Verbindung mit dem Server www.sfb1287.uni-potsdam.de schlug fehl.</p>
                <p>Wenn Sie die richtige Adresse eingegeben haben, können Sie Folgendes tun:</p>
                <ul>
                    <li>Versuchen Sie es später erneut.</li>
                    <li>Überprüfen Sie Ihre Netzwerkverbindung.</li>
                    <li>Überprüfen Sie, ob Sie die Berechtigung haben, auf das Internet zuzugreifen (Sie sind möglicherweise verbunden, aber hinter einer Firewall).</li>
                </ul>
                <span class="error_button"><a title="zur Startseite" href="<?php echo home_url(); ?>">Zurück zur Startseite!</a></span>
            <?php endif; ?>

            <?php if (ICL_LANGUAGE_CODE == 'en') : ?>
                <h1>Page was not found!</h1>
                <p>The connection with the server www.sfb1287.uni-potsdam.de failed.</p>
                <p>If you entered the correct address, you can do the following:</p>
                <ul>
                    <li>Try again later.</li>
                    <li>Check your network connection.</li>
                    <li>Check if you have permission to access the Internet (you may be connected but behind a firewall).</li>
                </ul>
                <span class="error_button"><a title="to homepage" href="<?php echo home_url(); ?>">Back to the home page!</a></span>
            <?php endif; ?>
        </div>
    </div>

    <?php wp_footer(); ?>

</body>

</html>