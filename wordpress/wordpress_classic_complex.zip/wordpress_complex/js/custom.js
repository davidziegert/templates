$(document).ready(function () {
	$("#my-main-menu .menu li").hover(
		function () {
			$(this).children('ul').slideDown('200');
		},
		function () {
			$('ul', this).slideUp('200');
		}
	);
});