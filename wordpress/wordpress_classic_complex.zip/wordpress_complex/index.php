<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo('charset'); ?>" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Site specific elements -->
	<title><?php the_title(); ?> | <?php bloginfo('name'); ?></title>

	<!-- CSS -->
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo get_bloginfo( 'template_directory' );?>/img/favicon.ico">
	<link rel="stylesheet" href="<?php echo get_bloginfo( 'template_directory' );?>/style.css">
	<link rel="stylesheet" href="<?php echo get_bloginfo( 'template_directory' );?>/css/reset.css">
	<link rel="stylesheet" href="<?php echo get_bloginfo( 'template_directory' );?>/css/custom.css">

	<!-- jQuery -->
	<script src="<?php echo get_bloginfo( 'template_directory' );?>/js/jquery-3.6.0.min.js"></script>
	<script src="<?php echo get_bloginfo( 'template_directory' );?>/js/custom.js"></script>
	
	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Cardo:400,700|Oswald" rel="stylesheet">
	
	<!-- Wordpress specific elements -->
	<?php wp_head(); ?>
</head>
<body>

	<div id="wrapper">
		<!-- Head -->
		<?php include 'header.php'; ?>	

		<!-- Nav -->
		<?php include 'nav.php'; ?>	

		<!-- Main -->
		<?php include 'main.php'; ?>	

		<!-- Aside -->
		<?php include 'sidebar.php'; ?>	

		<!-- Footer -->
		<?php include 'footer.php'; ?>			
	</div>

</body>

</html>