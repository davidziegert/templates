<main>
	
	<!-- Site Content -->
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<article id="my-content-tag">
			<h1><?php the_title(); ?></h1>
			<section><?php the_content(); ?></section>
		</article>
	<?php endwhile; endif; ?>

	<!-- Last Update -->
	<div id="my-update-tag">
		<span>Last update: <?php the_modified_date() ?></span>	
	</div>	
	
</main>