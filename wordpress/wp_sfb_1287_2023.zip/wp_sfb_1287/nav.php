<nav id="menu">
    <section>
        <div class="row">
            <?php wp_nav_menu(array('theme_location' => 'my-main-menu', 'container_class' => 'my-main-menu')); ?>
        </div>
    </section>
</nav>