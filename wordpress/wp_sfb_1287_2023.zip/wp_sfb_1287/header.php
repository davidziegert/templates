<header>
    <section>
        <div class="row first">
            <img class="logo" src="<?php echo get_bloginfo('template_directory'); ?>/img/logo_small.png" loading="lazy">
            <a href="<?php echo home_url(); ?>"><span class="title"><?php bloginfo('name'); ?></span><span class="subtitle"><?php bloginfo('description'); ?></span></a>
        </div>
        <div class="row second">
            <div class="lang-menu">
                <i class="fa fa-globe fa-2x" aria-hidden="true"></i>
                <?php wp_nav_menu(array('theme_location' => 'my-lang-menu', 'container_class' => 'my-lang-menu')); ?>
            </div>
            <div class="search-menu">
                <?php get_search_form(); ?>
            </div>          
        </div>
    </section>
</header>