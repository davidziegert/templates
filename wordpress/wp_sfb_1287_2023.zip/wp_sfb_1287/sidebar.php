<aside>
    <section>
        <div class="row">
            <?php $the_query = new WP_Query('posts_per_page=5'); ?>
            <?php if ($the_query->have_posts()): ?>
                <?php if (ICL_LANGUAGE_CODE == 'de'): ?>
                    <h3>Aktuelle News</h3>
                <?php endif; ?>
            
                <?php if (ICL_LANGUAGE_CODE == 'en'): ?>
                    <h3>Latest News</h3>
                <?php endif; ?>
            
                <div class="blog">
                    <!-- Loop through every Post -->
                    <?php while ($the_query->have_posts()): $the_query->the_post(); ?>
                        <?php if (ICL_LANGUAGE_CODE == 'de'): ?>
                            <div class="post">
                                <span class="post-title">
                                    <?php the_title(); ?>
                                </span>
                                <span class="post-link"><a title="weiterlesen" href="<?php the_permalink(); ?>">weiterlesen</a></span>
                            </div>
                        <?php endif; ?>
            
                        <?php if (ICL_LANGUAGE_CODE == 'en'): ?>
                            <div class="post">
                                <span class="post-title">
                                    <?php the_title(); ?>
                                </span>
                                <span class="post-link"><a title="read more" href="<?php the_permalink(); ?>">read more</a></span>
                            </div>
                        <?php endif; ?>
                    <?php endwhile; wp_reset_postdata(); ?>
                </div>
            <?php endif; ?>
        </div>
    </section>
</aside>