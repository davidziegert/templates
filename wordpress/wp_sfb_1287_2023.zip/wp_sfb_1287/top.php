<div class="top">
    <section>
        <div class="row">
            <div class="line"></div>
            <button class="hamburger" id="hamburger" onclick="toggleMobileMenu()">
                <span></span>
                <span></span>
                <span></span>
            </button>
        </div>
    </section>
</div>