<?php 

	/* ********************* */
	/* Register Custom Theme */
	/* ********************* */

	if ( ! function_exists( 'myfirsttheme_setup' ) ) :

	function myfirsttheme_setup()
	{

		/* Make theme available for translation. Translations can be placed in the /languages/ directory. */
			 
		load_theme_textdomain( 'myfirsttheme', get_template_directory() . '/languages' );

		/* Add default posts and comments RSS feed links */
		 
		add_theme_support( 'automatic-feed-links' );

		/* Enable support for post thumbnails and featured images. */
		 
		add_theme_support( 'post-thumbnails' );

		/* Enable support for the following post formats: aside, gallery, quote, image, and video */
		
		add_theme_support( 'post-formats', array ( 'aside', 'gallery', 'quote', 'image', 'video' ) );
	}
	
	endif;

	
	add_action( 'after_setup_theme', 'myfirsttheme_setup' );

	/* *********** */
	/* Breadcrumbs */
	/* *********** */

	function get_breadcrumb() 
	{
		echo '<a href="'.home_url().'" rel="nofollow">Home</a>';
						
		if (is_category() || is_single()) 
		{
			echo "&nbsp;&nbsp;&#187;&nbsp;&nbsp;";
			the_category(' &bull; ');
			
			if (is_single()) 
			{
				echo " &nbsp;&nbsp;&#187;&nbsp;&nbsp; ";
				the_title();
			}
		} 
		
		elseif (is_page()) 
		{
			echo "&nbsp;&nbsp;&#187;&nbsp;&nbsp;";
			echo the_title();
		} 
		
		elseif (is_search()) 
		{
			echo "&nbsp;&nbsp;&#187;&nbsp;&nbsp;Search Results for... ";
			echo '"<em>';
			echo the_search_query();
			echo '</em>"';
		}
	}

?>