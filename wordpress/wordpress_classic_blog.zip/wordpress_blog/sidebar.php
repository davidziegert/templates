<aside>
	<!-- Comments -->
	<div id="my-comment-form">
		<?php comments_template(); ?>
	</div>
</aside>