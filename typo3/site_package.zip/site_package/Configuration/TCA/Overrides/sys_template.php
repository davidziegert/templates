<?php

	defined('TYPO3') or die();

	$extensionKey = 'site_package';

	\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile(
		$extensionKey,
		'Configuration/TypoScript/',
		'Fluid Content Elements'
	);