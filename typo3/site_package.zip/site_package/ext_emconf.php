<?php
	$EM_CONF[$_EXTKEY] = [
		'title' => 'TYPO3 Site Package',
		'description' => 'TYPO3 Site Package',
		'category' => 'templates',
		'author' => 'your name',
		'author_email' => 'your mail',
		'author_company' => 'your company',
		'version' => '1.0.0',
		'state' => 'stable',
		'constraints' => [
			'depends' => [
				'typo3' => '12.0.0-12.99.99',
				'fluid_styled_content' => '12.0.0-12.99.99'
			],
			'conflicts' => [
			],
		],
		'uploadfolder' => 0,
		'createDirs' => '',
		'clearCacheOnLoad' => 1
	];
