function toggleMobileMenu() {
  if (window.matchMedia("(max-width: 9999px)").matches) {
    const hamburger = document.getElementById("hamburger");
    const mobile = document.getElementById("menu");
    hamburger.classList.toggle("open");
    mobile.classList.toggle("menu-open");
  }
}

let list = document.querySelectorAll(".dropdown");

function accordion(e) {
  e.stopPropagation();

  if (this.classList.contains("active")) {
    this.classList.remove("active");
  } else {
    if (this.parentElement.parentElement.classList.contains("active")) {
      this.classList.add("active");
    } else {
      for (i = 0; i < list.length; i++) {
        list[i].classList.remove("active");
      }

      this.classList.add("active");
    }
  }
}

for (i = 0; i < list.length; i++) {
  list[i].addEventListener("click", accordion);
}
